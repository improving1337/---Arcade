"""Controller-first menu with pixel artwork drawn locally (no external assets)."""
import math
from functools import wraps
import arcade
from PIL import Image, ImageDraw, ImageFilter

GLYPHS = {
    'G': ['0111110','1100011','1100000','1100000','1101111','1100011','1100011','1100011','0111110'],
    'E': ['1111111','1100000','1100000','1100000','1111100','1100000','1100000','1100000','1111111'],
    'O': ['0111110','1100011','1100011','1100011','1100011','1100011','1100011','1100011','0111110'],
    'M': ['1100011','1110111','1111111','1101011','1100011','1100011','1100011','1100011','1100011'],
    'T': ['1111111','1111111','0011000','0011000','0011000','0011000','0011000','0011000','0011000'],
    'R': ['1111110','1100011','1100011','1100011','1111110','1111000','1101100','1100110','1100011'],
    'Y': ['1100011','1100011','1100011','0110110','0011100','0011000','0011000','0011000','0011000'],
    'D': ['1111100','1100110','1100011','1100011','1100011','1100011','1100011','1100110','1111100'],
    'A': ['0011100','0110110','1100011','1100011','1111111','1100011','1100011','1100011','1100011'],
    'S': ['0111111','1100000','1100000','1100000','0111110','0000011','0000011','0000011','1111110'],
    'H': ['1100011','1100011','1100011','1100011','1111111','1100011','1100011','1100011','1100011'],
}


def consumes_events(cls):
    """Prevent handled view events from reaching legacy Window callbacks."""
    def consume(handler):
        @wraps(handler)
        def handled(self, *args, **kwargs):
            handler(self, *args, **kwargs)
            return True
        return handled
    for name, handler in list(vars(cls).items()):
        if name.startswith('on_') and callable(handler):
            setattr(cls, name, consume(handler))
    return cls


def artwork():
    """Separate background and transparent, beveled button sprites."""
    im = Image.new('RGBA', (1000, 560))
    d = ImageDraw.Draw(im)
    for y in range(560):
        t=y/560
        d.line((0,y,1000,y), fill=(int(170+43*t),0,int(40+4*t)))
    blocks = [(-35,-30,33,323),(47,-30,157,114),(47,128,158,227),
              (49,242,158,416),(173,-20,296,201),(173,215,296,318),
              (172,332,296,418),(312,-25,432,113),(312,129,431,305),
              (311,320,432,417),(448,-20,566,192),(448,207,566,418),
              (582,-25,696,104),(582,119,696,306),(582,321,696,418),
              (712,-20,832,198),(712,213,832,418),(848,-20,972,106),
              (848,122,972,303),(849,318,972,418),(987,-10,1080,416)]
    for x,y,r,b in blocks:
        d.rectangle((x,y,r,b),fill=(184,0,42),outline=(206,8,52),width=6)
        d.line((x+6,b-6,r-6,b-6,r-6,y+6),fill=(151,0,35),width=3)
    d.arc((350,-60,1240,390),35,105,fill=(233,14,60),width=3)
    d.line((0,424,1000,424),fill=(255,69,109),width=3)
    d.line((0,429,1000,429),fill=(115,0,29),width=4)
    for y in range(432,560): d.line((0,y,1000,y),fill=(190-int((y-432)*.22),0,40))
    for x in range(-20,1020,65):
        d.rectangle((x,439,x+55,551),outline=(196,5,45),width=3)
    # Individual letter shapes preserve the black counters at display resolution.
    mask=Image.new('L',im.size); md=ImageDraw.Draw(mask)
    x=142
    shifts=[0,-2,0,3,-1,1,-2,1,0,-1,2,0]
    idx=0
    for c in 'GEOMETRY DASH':
        if c==' ': x+=34; continue
        top=57+shifts[idx]; idx+=1
        for row,bits in enumerate(GLYPHS[c]):
            for col,bit in enumerate(bits):
                if bit=='1': md.rectangle((x+col*7,top+row*6,x+col*7+6,top+row*6+5),fill=255)
        x+=57
    outline=mask.filter(ImageFilter.MaxFilter(9))
    shadow=Image.new('RGBA',im.size); shadow.paste((40,44,8),mask=outline)
    im.alpha_composite(shadow,(3,6))
    im.paste((22,40,6),mask=outline)
    im.paste((252,255,192),mask=mask.filter(ImageFilter.MaxFilter(5)))
    gradient=Image.new('RGB',im.size); gd=ImageDraw.Draw(gradient)
    for y in range(45,125):
        t=max(0,min(1,(y-57)/54))
        gd.line((0,y,1000,y),fill=(int(185-100*t),int(255-30*t),int(46-24*t)))
    im.paste(gradient,mask=mask)
    # Raised inner edge gives the logo a cut-metal / lime finish.
    inner=Image.new('L',im.size); inner.paste(mask,(0,2))
    from PIL import ImageChops
    edge=ImageChops.subtract(mask,inner)
    im.paste((235,255,128),mask=edge)

    icons=[]
    def sprite(size):
        image=Image.new('RGBA',(size,size)); return image,ImageDraw.Draw(image)
    def shape(draw,points,fill,outline=(27,49,4),width=3):
        draw.polygon(points,fill=fill)
        draw.line(points+[points[0]],fill=outline,width=width,joint='curve')
    def bevel(draw,box,fill):
        x,y,r,b=box
        draw.rectangle(box,fill=fill,outline=(23,43,6),width=3)
        draw.line((x+4,b-4,x+4,y+4,r-4,y+4),fill=(239,255,171),width=2)
        draw.line((x+5,b-4,r-4,b-4,r-4,y+5),fill=(42,151,6),width=3)
    # Appearance: cyan blocks behind a yellow square face and a green frame.
    icon,q=sprite(124)
    for box in [(17,19,45,47),(79,19,107,47),(17,78,45,106),(79,78,107,106)]: bevel(q,box,(0,233,213))
    cross=[(43,10),(81,10),(81,43),(114,43),(114,81),(81,81),(81,114),(43,114),(43,81),(10,81),(10,43),(43,43)]
    shape(q,cross,(115,237,18));q.line(cross+[cross[0]],fill=(221,255,135),width=2)
    bevel(q,(31,31,93,93),(248,223,15))
    for x in (43,71):
        q.rectangle((x,45,x+11,58),fill=(12,211,224),outline=(32,57,5),width=2)
    q.rectangle((44,71,80,82),fill=(48,94,8));q.line((48,74,76,74),fill=(243,255,157),width=2)
    icons.append(icon)
    # Play: one continuous cross prevents visible seams at the junctions.
    icon,q=sprite(206)
    for box in [(28,28,80,80),(126,28,178,80),(28,126,80,178),(126,126,178,178)]: bevel(q,box,(0,235,215))
    cross=[(73,9),(133,9),(133,73),(197,73),(197,133),(133,133),(133,197),(73,197),(73,133),(9,133),(9,73),(73,73)]
    shape(q,[(x+2,y+4) for x,y in cross],(77,30,6),width=5)
    shape(q,cross,(101,226,12),width=4)
    q.line([(x+3,y+3) for x,y in cross]+[(76,12)],fill=(235,255,166),width=2)
    q.line((78,192,129,192,129,129,192,129,192,78),fill=(36,142,4),width=4)
    shape(q,[(78,45),(78,160),(161,103)],(22,47,4),width=4)
    shape(q,[(85,55),(85,149),(151,103)],(246,234,23),width=2)
    q.line((89,60,89,140),fill=(255,255,157),width=3)
    icons.append(icon)
    # Crossed wrench and hammer, with open wrench jaws.
    icon,q=sprite(124)
    for box in [(16,16,108,108)]: bevel(q,box,(105,231,13))
    q.line((30,96,87,35),fill=(28,52,5),width=18)
    q.line((30,96,87,35),fill=(247,222,16),width=11)
    shape(q,[(77,23),(91,16),(89,29),(97,35),(109,29),(104,43),(89,49),(76,39)],(247,226,19),width=3)
    q.line((34,32,95,94),fill=(28,52,5),width=18)
    q.line((34,32,95,94),fill=(242,218,14),width=10)
    shape(q,[(21,31),(36,17),(63,39),(48,55)],(246,231,22),width=3)
    q.line((26,31,37,22,58,39),fill=(255,255,139),width=2)
    icons.append(icon)
    for kind in ('settings','stats'):
        icon,q=sprite(91)
        q.ellipse((3,5,88,90),fill=(91,36,4))
        q.ellipse((3,2,88,87),fill=(34,60,4),outline=(22,41,4),width=2)
        q.ellipse((7,6,84,83),fill=(133,235,20),outline=(244,255,151),width=3)
        q.ellipse((14,13,77,76),outline=(41,158,7),width=3)
        if kind=='settings':
            teeth=[]
            for i in range(48):
                a=i*math.pi/24;r=28 if i%6 in (0,1,4,5) else 21
                teeth.append((45+r*math.cos(a),45+r*math.sin(a)))
            shape(q,teeth,(241,220,18),width=2)
            q.ellipse((33,33,57,57),fill=(103,222,16),outline=(45,84,4),width=3)
            q.arc((17,17,73,73),190,290,fill=(255,255,167),width=2)
        else:
            for x,h in [(25,23),(40,36),(55,49)]:
                bevel(q,(x,66-h,x+12,67),(246,226,14))
        icons.append(icon)
    return arcade.Texture(im), icons


@consumes_events
class MainMenu(arcade.View):
    positions=[(306,280),(500,280),(694,280),(450,55),(550,55)]
    labels=['APPEARANCE','PLAY','LEVELS','SETTINGS','STATISTICS']

    def __init__(self, game):
        super().__init__()
        self.game=game
        self.texture, self.icon_images=artwork()
        self.icons=[arcade.Texture(image) for image in self.icon_images]
        self.focused_icons=[]
        for image in self.icon_images:
            padded=Image.new('RGBA',(image.width+16,image.height+16))
            padded.alpha_composite(image,(8,8))
            alpha=padded.getchannel('A')
            glow=alpha.filter(ImageFilter.MaxFilter(7)).filter(ImageFilter.GaussianBlur(2))
            focus=Image.new('RGBA',padded.size,(0,0,0,0))
            focus.paste((239,255,156,230),mask=glow)
            focus.alpha_composite(padded)
            self.focused_icons.append(arcade.Texture(focus))
        for texture in [self.texture, *self.icons, *self.focused_icons]:
            game.ctx.default_atlas.add(texture)
        self.selected=1
        self.panel=None
        self.option=0
        self.palette=[(220,220,220),(117,255,30),(0,235,232),(255,224,25)]
        self.color=0

    def box(self):
        s=min(self.window.width/1000,self.window.height/560)
        return s,(self.window.width-1000*s)/2,(self.window.height-560*s)/2

    def text(self,text,x,y,size=20,color=(255,255,212)):
        s,ox,oy=self.box()
        arcade.draw_text(text,ox+x*s,oy+y*s,color,size*s,anchor_x='center',anchor_y='center',bold=True,font_name='DejaVu Sans')

    def on_draw(self):
        self.clear((65,0,19))
        s,ox,oy=self.box()
        arcade.draw_texture_rect(self.texture,arcade.LBWH(ox,oy,1000*s,560*s),pixelated=True)
        for i, ((x,y), texture) in enumerate(zip(self.positions,self.icons)):
            size=192 if i==1 else texture.width
            selected=i==self.selected and not self.panel
            if selected:
                # A small scale increase and a soft silhouette highlight replace
                # the large rectangular frame that broke the reference layout.
                size *= (texture.width+16)/texture.width*1.035
                texture=self.focused_icons[i]
            arcade.draw_texture_rect(texture,arcade.LBWH(
                ox+(x-size/2)*s,oy+(y-size/2)*s,size*s,size*s))
        if self.panel:
            arcade.draw_lbwh_rectangle_filled(ox+190*s,oy+115*s,620*s,300*s,(36,8,17,248))
            arcade.draw_lbwh_rectangle_outline(ox+190*s,oy+115*s,620*s,300*s,(192,255,70),4*s)
            self.text(self.panel,500,377,26)
            lines=self.lines()
            for i,line in enumerate(lines):
                self.text(('> ' if i==self.option else '')+line,500,310-i*46,18,(224,255,91) if i==self.option else (255,255,212))

    def on_update(self, dt):
        pass

    def lines(self):
        if self.panel=='SETTINGS': return [f'Fullscreen: {"ON" if self.game.is_full else "OFF"}','BACK']
        if self.panel=='STATISTICS': return [f'Attempts: {self.game.attempts}',f'Best: {self.game.best_percent}%','BACK']
        if self.panel=='APPEARANCE': return [f'Cube color: {self.color+1} / {len(self.palette)}','BACK']
        return ['LEVEL 1 — PLAY','BACK']

    def on_key_press(self,key,modifiers):
        if self.panel:
            if key in (arcade.key.UP,arcade.key.LEFT): self.option=(self.option-1)%len(self.lines())
            elif key in (arcade.key.DOWN,arcade.key.RIGHT): self.option=(self.option+1)%len(self.lines())
            return
        if key in (arcade.key.LEFT,arcade.key.RIGHT):
            row=[0,1,2] if self.selected<3 else [3,4]
            self.selected=row[(row.index(self.selected)+(1 if key==arcade.key.RIGHT else -1))%len(row)]
        elif key==arcade.key.DOWN: self.selected=3 if self.selected<=1 else 4
        elif key==arcade.key.UP: self.selected=1

    def on_mouse_press(self,x,y,button,modifiers):
        # Confirmation deliberately ignores cursor position for physical controllers.
        if button!=arcade.MOUSE_BUTTON_LEFT: return
        if self.panel:
            if self.option==len(self.lines())-1: self.panel=None; return
            if self.panel=='SETTINGS': self.game.toggle_fullscreen()
            elif self.panel=='APPEARANCE':
                self.color=(self.color+1)%len(self.palette)
                self.game.player_color=self.palette[self.color]
            elif self.panel=='LEVELS': self.play()
            return
        if self.selected==1: self.play()
        else: self.panel=self.labels[self.selected]; self.option=0

    def play(self):
        self.game.reset()
        self.game.attempts+=1
        self.window.show_view(PlayView(self.game,self))


@consumes_events
class PlayView(arcade.View):
    def __init__(self,game,menu):
        super().__init__(); self.game=game; self.menu=menu; self.selected=0

    def on_draw(self):
        self.game.on_draw()
        if self.game.dead or self.game.win:
            w,h=self.window.get_size()
            arcade.draw_lbwh_rectangle_filled(0,h/2-120,w,230,(15,15,15,245))
            arcade.draw_text('LEVEL COMPLETE' if self.game.win else 'TRY AGAIN',w/2,h/2+65,(212,255,78),26,anchor_x='center')
            for i,label in enumerate(['RESTART','MENU']):
                arcade.draw_text(('> ' if i==self.selected else '')+label,w/2+(i-.5)*240,h/2-20,(212,255,78) if i==self.selected else (180,180,180),22,anchor_x='center')

    def on_update(self,dt): self.game.on_update(dt)

    def on_key_press(self,key,modifiers):
        if self.game.dead or self.game.win:
            if key in (arcade.key.LEFT,arcade.key.RIGHT,arcade.key.UP,arcade.key.DOWN): self.selected=1-self.selected
        elif key==arcade.key.UP:
            self.game.jump_held=True; self.game.request_jump()
        elif key==arcade.key.DOWN: self.game.jump_held=False; self.window.show_view(self.menu)

    def on_key_release(self,key,modifiers):
        if key==arcade.key.UP: self.game.jump_held=False; self.game.jump_buffer=False

    def on_mouse_press(self,x,y,button,modifiers):
        if button!=arcade.MOUSE_BUTTON_LEFT: return
        if self.game.dead or self.game.win:
            if self.selected==1: self.window.show_view(self.menu)
            else: self.game.reset(); self.game.attempts+=1; self.selected=0
        else: self.game.request_jump()
